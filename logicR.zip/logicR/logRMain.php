
<?php


$data="Thabiso Ngobese";

  function myFunR($data)
  {
      echo strrev($data);

  }


  echo myFunR($data);



/*
$count=0;
$data="Thabiso Ngobese";
for($i=$count; $i<=$count; $i--)
{

    echo $i;
}*/
?>